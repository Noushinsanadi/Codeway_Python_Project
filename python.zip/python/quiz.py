# Simple Quiz Game in Python

def display_welcome():
    print("Welcome to the Quiz Game!")
    print("Answer the questions and test your knowledge.\n")

def ask_question(question, options, correct_answer):
    print(question)
    for i, option in enumerate(options, start=1):
        print(f"{i}. {option}")
    user_choice = int(input("Enter your choice (1, 2, 3, ...): "))
    return user_choice == correct_answer

def main():
    display_welcome()

    # Define quiz questions
    questions = [
        {
            "question": "What does CPU stand for?",
            "options": ["Central Processing Unit", "Computer Processing Unit", "Control Processing Unit"],
            "correct_answer": 1,
        },
        {
            "question": "What does RAM stand for?",
            "options": ["Random Access Memory", "Read-Only Memory", "Random Allocation Module"],
            "correct_answer": 1,
        },
        # Add more questions here
    ]

    total_questions = len(questions)
    score = 0

    for q in questions:
        if ask_question(q["question"], q["options"], q["correct_answer"]):
            print("Correct!\n")
            score += 1
        else:
            print(f"Incorrect! The correct answer was: {q['options'][q['correct_answer'] - 1]}\n")

    print(f"Your final score: {score}/{total_questions}")

    play_again = input("Do you want to play again? (yes/no): ").lower()
    if play_again == "yes":
        main()
    else:
        print("Thank you for playing!")

if __name__ == "__main__":
    main()
