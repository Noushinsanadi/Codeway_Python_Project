import requests
from decouple import Config, Csv

# Load your API keys from a .env file
config = Config()
config.read(".env")

GEOLOCATION_API_KEY = config.get("GEOLOCATION_API_KEY")
WEATHER_API_KEY = config.get("WEATHER_API_KEY")

def get_location(user_location):
    # Make a request to the Geolocation API
    geo_url = f"https://api.ipbase.com/v1/ip?api-key={GEOLOCATION_API_KEY}"
    response = requests.get(geo_url)
    location_data = response.json()

    # Extract latitude and longitude from the response
    latitude = location_data.get('latitude')
    longitude = location_data.get('longitude')

    return latitude, longitude

def get_weather(latitude, longitude):
    # Make a request to the OpenWeatherMap API
    weather_url = f"https://api.openweathermap.org/data/2.5/weather?lat={latitude}&lon={longitude}&appid={WEATHER_API_KEY}&units=metric"
    response = requests.get(weather_url)
    weather_data = response.json()

    # Extract temperature, humidity, and description from the response
    temperature = weather_data.get('main', {}).get('temp')
    humidity = weather_data.get('main', {}).get('humidity')
    description = weather_data.get('weather', [{}])[0].get('description')

    return temperature, humidity, description

def main():
    user_location = input("Enter a city name or zip code: ")
    latitude, longitude = get_location(user_location)

    if latitude is not None and longitude is not None:
        temperature, humidity, description = get_weather(latitude, longitude)

        print(f"Weather in {user_location}:")
        print(f"Temperature: {temperature}°C")
        print(f"Humidity: {humidity}%")
        print(f"Description: {description}")
    else:
        print("Unable to retrieve location data.")

if __name__ == "__main__":
    main()
x